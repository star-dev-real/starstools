from mitmproxy import http
import json

def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {'amount': 1000}  

def response(flow: http.HTTPFlow):
    if "api.bedrocklearning.org/api/students" in flow.request.pretty_url and "dashboard" in flow.request.pretty_url:
        config = load_config()
        amount = config.get('amount', 1000)
        
        try:
            response_text = flow.response.content.decode('utf-8')
            data = json.loads(response_text)
            
            data['firstname'] = f"{data.get('firstname', 'User')} (StarTools Running)"
            
            items = ['points', 'pointsWeek', 'time', 'timeWeek']
            for item in items:
                if item in data:
                    data[item] = amount
                    print(f"Changed {item} to {amount}")
            
            flow.response.content = json.dumps(data).encode('utf-8')
            
        except Exception as e:
            print(f"Error modifying response: {e}")