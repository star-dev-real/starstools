from mitmproxy import http
import os
import json
import signal
import time

def request(flow: http.HTTPFlow):
    if "api.bedrocklearning.org/api/students" in flow.request.url:
        if flow.request.method == "GET" and "authorization" in flow.request.headers:
            token = flow.request.headers["authorization"]
            url = flow.request.url.split('?')[0]  
            data = {
                "token": token,
                "api-url": url,
                "timestamp": int(time.time())
            }
            with open("api.json", "w") as f:
                json.dump(data, f)
            print(f"Token captured and saved to api.json")
            os.kill(os.getppid(), signal.SIGTERM)